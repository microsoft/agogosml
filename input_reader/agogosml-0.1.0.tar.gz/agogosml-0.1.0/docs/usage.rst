=====
Usage
=====

To use Agogosml in a project::

    import agogosml
