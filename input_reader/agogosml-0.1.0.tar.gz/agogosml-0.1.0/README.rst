========
Agogosml
========


.. image:: https://img.shields.io/pypi/v/agogosml.svg
        :target: https://pypi.python.org/pypi/agogosml

.. image:: https://readthedocs.org/projects/agogosml/badge/?version=latest
        :target: https://agogosml.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Agogosml Library


* Free software: MIT license
* Documentation: https://agogosml.readthedocs.io.

