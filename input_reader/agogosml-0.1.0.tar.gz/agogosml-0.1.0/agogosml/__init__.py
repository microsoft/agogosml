# -*- coding: utf-8 -*-

"""Top-level package for Agogosml."""

__author__ = """Rami Sayar"""
__email__ = 'rami.sayar@microsoft.com'
__version__ = '0.1.0'
